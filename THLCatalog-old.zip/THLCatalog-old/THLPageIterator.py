__author__ = 'thangrove'

class THLPageIterator:
    def __init__(self, st, en):
        pts = st.split('.')
        # go back one line to include start line given
        stpg = pts[0]
        stln = int(pts[1]) - 1
        if stln == 0:
            if stpg.find('b') > -1:
                stpg = stpg.replace('b', 'a')
            else:
                stpg = str(int(stpg.replace('a','')) - 1) + 'b'
            stln = 6
        self.pg = stpg
        self.ln = int(stln)
        pts = en.split('.')
        self.endpg = pts[0]
        self.endln = pts[1]

    def __iter__(self):
        return self

    def next(self):
        self.ln += 1
        if self.ln > 6:
            if self.pg.find('a') > -1:
                self.pg = self.pg.replace('a', 'b')
            else:
                npg = self.pg.replace('b', '')
                npg = int(npg) + 1
                self.pg = str(npg) + "a"
            self.ln = 1

        if self.pg == self.endpg and int(self.ln) > int(self.endln):
            raise StopIteration
        elif self.pg == self.endpg.replace('a', 'b'):
            raise StopIteration
        elif int(self.pg.replace('a', '').replace('b', '')) > int(self.endpg.replace('a', '').replace('b', '')):
            raise StopIteration
        else:
            return self.pg + "." + str(self.ln)

if __name__ == "__main__":
    pgit = THLPageIterator('2a.5', '3a.1')
    for p in pgit:
        print p,