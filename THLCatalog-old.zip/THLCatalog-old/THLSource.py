# coding=utf-8

__author__ = 'thangrove'

import codecs
from lxml import etree
import re
from StringIO import StringIO
from THLPageIterator import THLPageIterator

####  THLSource Class ####
class THLSource(object):
    """THL Text: An Object for manipulating XML data about one text in a catalog

        Attributes:
            source_url : (optional) Url to the source file for the text
            stype : (default = xml) type of source being loaded (xml or text)
            text_root : root element of source
            bibl_url : (optional) URL to the Bibl file
            bibl_root : root element of bibl
    """

    def __init__(self, source_url='', is_xml=False):
        self.source_url = source_url
        self.source = self.read_doc(self.source_url)
        self.mytree = None
        self.text = ''
        self.is_xml = is_xml

    def convert_input_to_xml(self):
        mysource = self.source
        mysource = mysource.replace('[b1]', '[1b]', 1)
        newsource = re.sub(r'\[([^\]\.]+)\]', r'<milestone n="\1" unit="page"/>', mysource)
        newsource = re.sub(r'\[([^\.]+\.[\d])\]', r'<milestone n="\1" unit="line"/>', newsource)
        self.text = u'<div>' + newsource + u'</div>'
        ftxt = StringIO(self.text)
        self.mytree = etree.parse(ftxt)
        self.source = self.mytree.getroot()
        self.is_xml = True

    def write(self, outurl):
        if self.is_xml:
            # TODO: do something here NEEDS TO BE FLESHED OUT!
            xfile = codecs.open(outurl, "w", "utf-8")

        else:
            xfile = codecs.open(outurl, "w", "utf-8")
            xfile.write(self.text)
            xfile.close()

    def getmilestone(self, msnum):
        lpath = '/*//milestone[@n="{0}"]'.format(msnum)
        ms = self.source.xpath(lpath)
        return ms[0]

    def getline(self, linenum):
        outln = u''
        if linenum.find(".1") > -1:
            pgnum = linenum.replace(".1", "")
            pg = self.getmilestone(pgnum)
            outln += etree.tostring(pg)
        ln = self.getmilestone(linenum)
        tail = ln.tail
        ln.tail = u''
        outln += etree.tostring(ln) + tail
        return outln

    def getchunk(self, stln, endln):
        outchunk = u''
        for pn in THLPageIterator(stln, endln):
            outln = self.getline(pn)
            outchunk += outln
        return outchunk

    @staticmethod
    def get_xml_root_of_url(url):
        if len(url) > 0:
            xtree = etree.parse(url)
            return xtree.getroot()
        else:
            return False

    @staticmethod
    def read_doc(url):
        vol_in_stream = codecs.open(url, 'r', encoding='utf-16')
        txt = vol_in_stream.read()
        return txt

def whatisthis(s):
    if isinstance(s, str):
        print "ordinary string"
    elif isinstance(s, unicode):
        print "unicode string"
    else:
        print "not a string"

if __name__ == "__main__":
    #  Test text: /Users/thangrove/S4ites/texts/dev/catalogs/xml/kt/d/texts/0002/kt-d-0002-text.xml
    #  Test Source volume: /Users/thangrove/Documents/Project Data/THL/DegeKT/ProofedVols/005 FINAL tags.txt
    #  test_path = '/Users/thangrove/Sites/texts/dev/catalogs/xml/kt/d/texts/0002/kt-d-0002-text.xml'
    test_path2 = '/Users/thangrove/Documents/Project Data/THL/DegeKT/ProofedVols/test/testvol.txt'
    chunkout = '/Users/thangrove/Documents/Project Data/THL/DegeKT/ProofedVols/test/testchunk.xml'
    text2 = THLSource(test_path2)
    text2.convert_input_to_xml()
    ms = text2.getmilestone('2a.6')
    print etree.tostring(ms, encoding='utf-8')

   # text2.write(outpath)

    chunk = text2.getchunk('2a.5', '3a.1')
    print chunk
    xfile = codecs.open(chunkout, "w", "utf-8")
    xfile.write(chunk)
    xfile.close()