# coding=utf-8

__author__ = 'thangrove'

import codecs
from lxml import etree
import re

####  THLText Class ####


class THLText(object):
    """THL Text: An Object for manipulating XML data about one text in a catalog

        Parameter Attributes:
            text_url : (optional) Url to the source file for the text
            bibl_url : (optional) URL to the Bibl file
        Internal Attributes:
            text_root : oot element of source
            bibl_root : root element of bibl
    """

    def __init__(self, text_url, bibl_url=''):
        self.text_url = text_url                        # Url for the text XML file
        self.tree = None
        self.text = self.get_xml_root(self.text_url)    # text is the root element of text
        self.bibl_url = ''                              # bibl_url is the url for the bibl xml file
        self.bibl = None                                # bibl is the root element of the bibl file
        if bibl_url:                                    # Can set bibl_url at init or after by calling function
            self.set_bibl(bibl_url)
        pts = text_url.split('/')
        self.file_name = ''                             # file_name is last string part of url
        while self.file_name == '':
            self.file_name = pts.pop()

    def set_bibl(self, bibl_url):
        """Function for setting the bibl url and element of a text"""
        self.bibl_url = bibl_url
        self.bibl = self.get_xml_root(self.bibl_url)

    def getrange(self):
        """Returns the page rage of text as a 2 item list, first item is start line, second is end line"""
        xp = '/*//body//milestone[@unit="line"]/@n'
        mss = self.text.xpath(xp)
        return [mss[0],  mss.pop()]

    def replace_p(self, newp='<p></p>'):
        """Replaces the content of the text'sp element with new (proofed) Tibetan text"""
        # Check if multiple <p> elements and write warning
        pct = len(self.text.xpath('/*//text//p'))
        if pct > 1:
            print "{0} <p> elements found in {1}. Replacing all with new text!".format(pct, self.file_name)
        # Read in file
        fout = codecs.open(self.text_url, 'r', encoding='utf-8')
        mytext = fout.read()
        fout.close()
        # Use all inclusive regex to replace <p>
        # Done this way because using lxml resolves all XML entities into XML, which we don't want for writing back out
        pattern = r'<p>[\s\S]+</p>'
        mytext = re.sub(pattern, newp, mytext)
        return mytext

    def write(self, outurl):
        # place holder for now
        # TODO: Flesh this out
        self.tree.write(outurl, encoding='utf-8', xml_declaration=True)

    def get_xml_root(self, url=''):
        if len(url) > 0:
            print "url is: {0}".format(url)
            self.tree = etree.parse(url)
            return self.tree.getroot()
        else:
            return False

    @staticmethod
    def read_doc(url):
        vol_in_stream = codecs.open(url, 'r', encoding='utf-16')
        txt = vol_in_stream.read()
        return txt

if __name__ == "__main__":
    text1url = '/Users/thangrove/Sites/texts/dev/catalogs/xml/kt/d/texts/0002/kt-d-0002-text.xml'
    outpath = '/Users/thangrove/Documents/Project Data/THL/DegeKT/ProofedVols/test/'
    outfile = outpath + 'kd-d-0002-replaced.xml'
    text1 = THLText(text1url)
    rng = text1.getrange()
    print "Before replaceing the text ranges from {0} to {1}".format(rng[0], rng[1])
    #text1.write(outfile)
    textout = text1.replace_p('<p>Me new</p>')
    f = codecs.open(outfile, 'w', encoding='utf-8')
    f.write(textout)
    f.close()
